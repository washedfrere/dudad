-=1.1.0.0 version=-
Bugs Fixed:
- Visita http://blitzhive.com/Bugs/
Upgrades:
- Visita http://blitzhive.com/Mejoras/

-=1.0.0.0 version=-
Bugs Fixed:
- Corregidos peque�os fallos en modo blog
- Fallo corregido en usuarios sin credenciales
- Fallo corregido para evitar respuestas an�nimas
- Ahora borrar y aprobar respuestas funciona correctamente

Upgrades:
- C�digo m�s legible para w.php,user.php,cat.php y index.php
- Los tags se rellenan despu�s de subir
- El css ahora es m�s responsive

Instalaci�n manual del CMS Blitzhive
**Alpha Version

1# Descarga: http://blitzhive.com/download/

2# Edita el archivo config.php y cambia las variables $cnfHome='http://tusitio/';
  y $cnfAdm='blitz' por tu nombre futuro de administrador ejemplo: $cnfAdm='administrador'
   
3# Sube los archivos, dir�gete a http://tusitio/register.php y registra el usuario administrador    

4# Haz login con el nuevo usuario y dir�gete a admin.php.

5# Configura tu blitzhive, :)

6# Si quieres usarlo sin categor�as, simplemente renombra cat.php -> index.php

Reporta fallos en :http://blitzhive.com/Bugs/
A�ade mejoras: http://blitzhive.com/Mejoras/
