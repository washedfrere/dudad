<?php
include '../bin/comun.php';
include '../bin/dh.php';
include '../bin/control.php';
echo "<HTML>";
echo "<HEAD><TITLE>";
if (!isset($_GET["ola"])) {$ola="actual";}
else {$ola=$_GET["ola"];}
echo "?!".$ola;
echo '</TITLE><link rel="shortcut icon" href="favicon.ico"></HEAD>';
echo "<BODY>";
echo '<center>';
?><a href= "#"
 onmouseOver="document.logo.src='../ico/dudad_logo_pekenio.png';"
 onClick= "return false;"
 onmouseOut="document.logo.src='../ico/dudad_logo_mini.png';"><img name="logo" src="../ico/dudad_logo_mini.png" border="0"></a>
<?php
if ( $ola=="actual")
{ echo '<b><a href="navegar.php?ola=actual"> ACTUAL </a></b>
<a href="navegar.php?ola=foro"> Foro </a>
<a href="navegar.php?ola=wiki"> Wiki </a>
<a href="navegar.php?ola=colabor"> Colabor </a>
<a href="navegar.php?ola=login"> Login </a>';
} elseif ( $ola=="colabor")
{ echo '<b><a href="navegar.php?ola=colabor"> COLABOR </a></b>
<a href="navegar.php?ola=actual"> Actual </a>
<a href="navegar.php?ola=foro"> Foro </a>
<a href="navegar.php?ola=wiki"> Wiki </a>
<a href="navegar.php?ola=login"> Login </a>';
} elseif ( $ola=="foro" )
{ echo '<b><a href="navegar.php?ola=foro"> FORO </a></b>
<a href="navegar.php?ola=actual"> Actual </a>
<a href="navegar.php?ola=wiki"> Wiki </a>
<a href="navegar.php?ola=colabor"> Colabor </a>
<a href="navegar.php?ola=login"> Login </a>';
} elseif ( $ola=="login" )
{ echo '<b><a href="navegar.php?ola=login"> LOGIN </a></b>
<a href="navegar.php?ola=actual"> Actual </a>
<a href="navegar.php?ola=foro"> Foro </a>
<a href="navegar.php?ola=wiki"> Wiki </a>
<a href="navegar.php?ola=colabor"> Colabor </a>'; 
} elseif ( $ola=="wiki" )
{ echo '<b><a href="navegar.php?ola=wiki"> WIKI </a></b>
<a href="navegar.php?ola=actual"> Actual </a>
<a href="navegar.php?ola=foro"> Foro </a>
<a href="navegar.php?ola=colabor"> Colabor </a>
<a href="navegar.php?ola=login"> Login </a>'; }
else { echo '<b><a href="navegar.php?ola=actual"> ACTUAL </a></b>
<a href="navegar.php?ola=foro"> Foro </a>
<a href="navegar.php?ola=wiki"> Wiki </a>
<a href="navegar.php?ola=colabor"> Colabor </a>
<a href="navegar.php?ola=login"> Login </a>';}
echo '(<IMG SRC="'.$ESFERA.'" BORDER="0"/>'.$USUARIO.'<IMG SRC="'.$ESFERA.'" BORDER="0"/>)';
echo '</center>';
if ( $ola=="actual")
{ include "actual.php";
} elseif ( $ola=="colabor")
{ include "colabor.php";
} elseif ( $ola=="foro" )
{ include "foro.php";
} elseif ( $ola=="login" )
{ include "login.php"; 
} elseif ( $ola=="wiki" )
{ include "wiki.php"; }
else { include "actual.php"; }
?>
<script language="javascript"> 
//Degradado de colores
hexadecimal = new Array("0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F") 

function convierteHexadecimal(num){ 
   	var hexaDec = Math.floor(num/16) 
   	var hexaUni = num - (hexaDec * 16) 
   	return hexadecimal[hexaDec] + hexadecimal[hexaUni] 
} 

color_decimal = 150

function degradado(){ 
   	color_decimal++
   	 
   	color_hexadecimal = convierteHexadecimal(color_decimal) 
   	document.bgColor =  color_hexadecimal + convierteHexadecimal(180) + convierteHexadecimal(180) 

   	//la llamo con un retardo 
   	if (color_decimal < 180) 
      	 setTimeout("degradado()",1) 
} 

degradado() 
</script>
<?php 
echo "</BODY>";
echo "</HTML>";
?>