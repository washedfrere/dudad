<script type="text/javascript">
function validaclave1()
{
var clavea=document.forms["valclave1"]["llaven"].value
var claveb=document.forms["valclave1"]["llavenn"].value
if (clavea!=claveb)
  {
  alert("Las claves no coinciden");
  return false;
  }
}
function validaclavenew()
{
var clavea=document.forms["valclavenew"]["llavenew"].value
var claveb=document.forms["valclavenew"]["llavenewb"].value
if (clavea!=claveb)
  {
  alert("Las claves no coinciden");
  return false;
  }
}
</script>
<?php
echo $_SESSION['msgusuario']."<br>";
?>
<table border="0" align="center">
<?php
if($USUARIO==USERGUEST)
{ echo '
<tr><td align="right">
<hr>
<h3>Usuario de conexi&oacute;n</h3>
<form action="" method="post" name="conecta">
Usuario: <input type="text" name="username" />
<br>Contrase&ntilde;a: <input type="password" name="llave" />
<br><input type="submit" value="Entrar" />
</form>
</td></tr>';
}
if($USUARIO!=USERGUEST)
{
echo '
<tr><td align="right">
<hr>
<h3>Cambio de clave</h3>
<form action="" method="post" name="valclave1" onsubmit="return validaclave1();">
Usuario: <input type="text" name="username" />
<br>Contrase&ntilde;a: <input type="password" name="llave" />
<br>Nueva: <input type="password" name="llaven" />
<br>Repetir: <input type="password" name="llavenn" />
<br><input type="submit" value="Nueva Clave"/>
</form>
</td>
</tr>
';
echo '
<tr><td align="right">
<hr>
<h3>Desconectarse</h3>
<form action="" method="post">
Usuario: <input type="text" name="useroff" />
<br>Contrase&ntilde;a: <input type="password" name="llaveoff" />
<br><input type="submit" value="Desconectar"/>
</form>
</td></tr>
';}
if ((isset($_GET['dafero']) && $_GET['dafero']='espartaco') || $CLASE<=CLASE_ALTA )
{
echo '
<tr><td align="right">
<hr>
<h3>Nuevo Usuario</h3>
<form action="" method="post" name="valclavenew" onsubmit="return validaclavenew();">
Usuario: <input type="text" name="usernew" />
<br>Clase: <input type="text" name="nivelnew" />
<br>Contrase&ntilde;a: <input type="password" name="llavenew" />
<br>Repetir: <input type="password" name="llavenewb" />
<br><input type="submit" value="Nuevo Usuario"/>
</form>
</td></tr>
';}
?>
</table>