<H3>Est&aacute;s escribiendo como usuario p&uacute;blico.</h3>
Puedes escribir mensajes en la zona p&uacute;blica, pero aparecen codificados y solamente los usuarios reconocidos podr&aacute;n leerlos.<br>
Desde aqu&iacute; puedes pedir tu registro o comentarnos algo que creas interesante.<br>
Los usuarios reconocidos leer&aacute;n tu comentario y actuar&aacute;n, o no, en consecuencia.<br>
<h2>Conf&iacute;a en tu instinto.</h2>