<h3>Centro de colaboraci&oacute;n</h3>
<?php
if($CLASE<=CLASE_ALTA)
{
}
elseif($CLASE<=CLASE_MEDIA) 
{
}
else 
{?>
Tenemos que informarte que para poder ver el contenido de esta p&aacute;gina deber&iacute;as haber entrado con un usuario reconocido.<br>
<h3>El contenido de...</h3>
... la web es complejo y muy vol&aacute;til. Este espacio est&aacute; dedicado a traspasar conocimiento y experiencias de forma digital.<br>
Aqu&iacute; compartimos datos, fotos, escritos propios y nos pasamos dicha informaci&oacute;n de forma privada. Por eso t&uacute; no puedes verla.<br>
<br>
Si crees que debes poder compartir cosas con nuestros co-laborantes, <a href="navegar.php?ola=foro">p&aacute;sate por el foro</a> y seguro que alguien habr&aacute;
que te haga caso. Si no hay nadie que te haga caso, hay miriadas de web esper&aacute;ndote; el mundo es algo m&aacute;s que
una p&aacute;gina WEB.
<h2>Divi&eacute;rtete</h2>
Y procura estar feliz el mayor tiempo posible. T&oacute;mate tu tiempo sin perderlo. Piensa. Duda de todo, pero act&uacute;a con energ&iacute;a y entusiasmo.<br>
Sobre todo y ante todo: s&eacute; t&uacute;. 
<?php
}
?>