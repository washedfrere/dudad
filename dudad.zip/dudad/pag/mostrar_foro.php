<?php
//Paginación de los foros
if  (isset($_GET['pagforo']) && $_GET['pagforo']!=NULL){ $PAGFORO=$_GET['pagforo'];}
else {$PAGFORO=0;}

//Paginación de los mensajes
if  (isset($_GET['pagmens']) && $_GET['pagmens']!=NULL){ $PAGMENS=$_GET['pagmens'];}
else {$PAGMENS=0;}

?>
<TABLE width="100%" border="0">
<tr><TD width="20%" bgcolor="lightgrey">
Temas
<a href="navegar.php?ola=foro&buscaforo=1"
 onmouseOver="document.buscaforo.src='../ico/lupa.png';"
 onmouseOut="document.buscaforo.src='../ico/lupa_no.png';"
><img src="../ico/lupa_no.png" name="buscaforo" alt="buscar" border="0" ></a>
<?php
if ($CLASE < CLASE_MEDIA)
{
echo '
<a href="navegar.php?ola=foro&nuevoforo=1"
 onmouseOver="document.escrforo.src=\'../ico/escribe.png\';"
 onmouseOut="document.escrforo.src=\'../ico/escribe_no.png\';"
><img src="../ico/escribe_no.png" name="escrforo" alt="nuevo tema" border="0" ></a>
';
}
?>
</td><td width="80%" bgcolor="lightgrey">
Mensajes del tema <?php echo $_SESSION['temaactual']; ?>
<a href="navegar.php?ola=foro&buscamens=1"
 onmouseOver="document.buscamens.src='../ico/lupa.png';"
 onmouseOut="document.buscamens.src='../ico/lupa_no.png';"
><img src="../ico/lupa_no.png" name="buscamens" alt="buscar" border="0" ></a>
<?php
if ($CLASE < CLASE_BAJA)
{
echo '
<a href="navegar.php?ola=foro&nuevomens=1"
 onmouseOver="document.escrmens.src=\'../ico/escribe.png\';"
 onmouseOut="document.escrmens.src=\'../ico/escribe_no.png\';"
><img src="../ico/escribe_no.png" name="escrmens" alt="nuevo mensaje" border="0" ></a>
';
}
?>
</td></tr>
<tr><td>
<?php include "../bin/consulta_foros.php"; ?>
</td><td>
<?php if ($_SESSION['idtemaactual']!=null){include "../bin/consulta_mensajes.php";} ?>
</td></tr>
</table>