<?php

/*
 * @CODOLICENSE
 */

namespace Controller;

class user {

    public $view = false;
    public $css_files = array();
    public $js_files = array();
    private $smarty;

    public function __construct() {

        $this->db = \DB::getPDO();
        $this->smarty = \CODOF\Smarty\Single::get_instance();
    }

    public function login() {

        \CODOF\Hook::call('before_controller_login');

        $this->view = 'user/login';
        if (isset($_SESSION[UID . 'USER']['id'])) {
            header('Location: ' . \CODOF\User\User::getProfileUrl());
            exit;
        }
        
        $user = \CODOF\User\User::get();
        $this->smarty->assign('can_view_forum', $user->can('view forum'));

        \CODOF\Hook::call('after_controller_login');
        \CODOF\Store::set('sub_title', _t('User login'));
    }

    public function logout() {

        $user = \CODOF\User\User::get();
        $user->logout();

        if (\CODOF\Plugin::is_active('sso')) {

            header('Location: ' . \CODOF\Util::get_opt('sso_logout_user_path'));
            exit;
        }

        header('Location: ' . RURI);
    }

    public function profile($id, $action) {

        $this->view = 'user/profile/view';

        \CODOF\Store::set('meta:robots', 'noindex, follow');

        if ($id == null) {

            $id = 0;
        }

        if ($action == null) {

            $action = 'view';
        }


        $profile = new \CODOF\User\Profile();

        $uid = $profile->get_uid($id);

        $currUser = \CODOF\User\User::get();
        if (!$currUser->can('view user profiles') && $uid != $currUser->id) {

            //if current user cannot view user profiles and if he is trying
            //to view a profile that is not his, we need to deny him permission
            $action = 'deny';
        }


        $user = \CODOF\User\User::getByIdOrUsername($uid, $uid);

        if ($user) {

            $user->avatar = $user->getAvatar();
            //pass user object to template
            $this->smarty->assign('user', $user);
            $this->smarty->assign('rname', \CODOF\User\User::getRoleName($user->rid));


            \CODOF\Store::set('sub_title', $user->username);
            $can_edit = $this->can_edit_profile($uid);

            if ($action == 'edit' && $can_edit) {

                $this->view = 'user/profile/edit';
                $this->css_files = array('profile_edit');
                $this->js_files = array(
                    array(DATA_PATH . 'assets/js/user/profile/edit.js', array('type' => 'defer')),
                    array('bootstrap-slider.js', array('type' => 'defer'))
                );

                $subscriber = new \CODOF\Forum\Notification\Subscriber();

                $categories = $subscriber->getCategorySubscriptions($uid);
                $topics = $subscriber->getTopicSubscriptions($uid);

                $this->smarty->assign('categories', $categories);
                $this->smarty->assign('topics', $topics);

                $this->smarty->assign('signature_char_lim', \CODOF\Util::get_opt('signature_char_lim'));
            } else if ($action == 'view') {

                $this->view = 'user/profile/view';
                if ($uid != $currUser->id) {

                    $user->incProfileViews();
                }

                $this->smarty->assign('user_not_confirmed', $uid == $currUser->id && !$user->isConfirmed());
                $this->smarty->assign('can_edit', $can_edit);

                $this->css_files = array('profile_view');
                $this->js_files = array(
                    array(DATA_PATH . 'assets/js/user/profile/view.js', array('type' => 'defer'))
                );
                \CODOF\Hook::call('before_profile_view', $user);
            } else {

                $this->view = 'access_denied';
            }
        } else {
            $this->view = 'not_found';
        }
    }

    public function can_edit_profile($id) {

        $user = \CODOF\User\User::get();
        if (!isset($id) || !$id) {
            //if id is not passed
            return false;
        } else {

            //if not editing own profile and does not have permission to do so.
            //if ($id != $user->id && !$user->can('edit others profiles')) {
            //    return false;
            //}
            
        }

        return $id == $user->id;
    }

    public function edit_profile($id) {

        $edit = \CODOF\User\User::get();
        $id = (int) $id;

        if (!$this->can_edit_profile($id)) {

            $this->view = 'access_denied';
            return false;
        }

        $values = array(
            "name" => \CODOF\Filter::msg_safe($_POST['name']),
            "signature" => \CODOF\Format::omessage($_POST['signature'])
        );

        $success = true;

        if (isset($_FILES) && $_FILES['avatar']['error'] != UPLOAD_ERR_NO_FILE) {

            $success = false;
            \CODOF\File\Upload::$width = 128;
            \CODOF\File\Upload::$height = 128;
            \CODOF\File\Upload::$resizeImage = true;
            \CODOF\File\Upload::$resizeIconPath = DATA_PATH . PROFILE_ICON_PATH;
            $result = \CODOF\File\Upload::do_upload($_FILES['avatar'], PROFILE_IMG_PATH);

            if (\CODOF\File\Upload::$error) {

                $this->smarty->assign('file_upload_error', $result);
            } else {

                $values["avatar"] = $result['name'];
                $success = true;
            }
        }

        $edited = $edit->set($values);


        if (!$edited) {

            Util::log("Failed to update user details profile/id/edit");
            $success = false;
        }

        $this->smarty->assign('user_profile_edit', $success);


        $this->profile($id, 'edit');
    }

    public function register($do) {

        if (isset($_SESSION[UID . 'USER']['id'])) {
            header('Location: ' . \CODOF\User\User::getProfileUrl());
            exit;
        }

        $this->view = 'user/register';
        $set_fields = array('username', 'password', 'mail');
        $req_fields = array('username', 'password', 'mail');

        if (\CODOF\Util::is_set($_REQUEST, $set_fields) && !\CODOF\Util::is_empty($_REQUEST, $req_fields) && $do) {

            $register = new \CODOF\User\Register($this->db);

            $register->username = str_replace('"', '&quot;', $_REQUEST['username']);
            $register->name = null; //$_REQUEST['name'];
            $register->password = $_REQUEST["password"];
            $register->mail = $_REQUEST['mail'];
            $register->rid = ROLE_UNVERIFIED;

            $errors = $register->get_errors();

            if (empty($errors)) {

                $errors = $register->register_user();
                $register->login();
                header('Location: ' . \CODOF\User\User::getProfileUrl());
                exit;
            }

            $this->smarty->assign('errors', $errors);
        } else {

            $register = new \stdClass();
            $register->username = null;
            $register->name = null; //$_REQUEST['name'];
            $register->password = null;
            $register->mail = null;

            if (\CODOF\Util::get_opt('captcha') == "enabled") {

                require ABSPATH . 'sys/Ext/recaptcha/recaptchalib.php';
                $publickey = \CODOF\Util::get_opt('captcha_public_key'); // you got this from the signup page
                $this->smarty->assign('recaptcha', recaptcha_get_html($publickey));
            }
        }

        $this->js_files = array(
            array(DURI . 'assets/js/user/register.js', array('type' => 'defer'))
        );

        $this->smarty->assign('min_pass_len', \CODOF\Util::get_opt('register_pass_min'));
        $this->smarty->assign('min_username_len', \CODOF\Util::get_opt('register_username_min'));
        $this->smarty->assign('register', $register);

        \CODOF\Store::set('sub_title', 'Register');
    }

    public function confirm() {

        $this->view = 'user/confirm';
        $action = array();

        if (empty($_GET['user']) || empty($_GET['token'])) {
            $action['result'] = 'VAR_NOT_PASSED';
            //$action['text'] = 'We are missing variables. Please double check your email.';
        } else {

            //cleanup the variables
            $username = $_GET['user'];
            $token = $_GET['token'];

            //check if the key is in the database
            $qry = "SELECT username FROM  " . PREFIX . "codo_signups WHERE username=:username AND token=:token LIMIT 1 OFFSET 0";
            $stmt = $this->db->prepare($qry);
            $result = $stmt->execute(array("username" => $username, "token" => $token));

            if ($result) {

                //get the confirm info
                $res = $stmt->fetch();

                //confirm the email and update the users database
                $qry = "UPDATE " . PREFIX . "codo_users SET user_status=1 WHERE username=:username";
                $stmt = $this->db->prepare($qry);
                $stmt->execute(array("username" => $username));
                $user = \CODOF\User\User::getByUsername($username);
                $qry = "UPDATE " . PREFIX . "codo_user_roles SET rid=:rid WHERE uid=" . $user->id;
                $stmt = $this->db->prepare($qry);
                $stmt->execute(array("rid" => ROLE_USER));

                //delete the signup rows associated with the selected username
                $qry = "DELETE FROM " . PREFIX . "codo_signups WHERE username = '" . $res['username'] . "'";
                $this->db->query($qry);

                $action['result'] = 'SUCCESS';
            } else {

                $action['result'] = 'VAR_NOT_FOUND';
            }
        }

        \CODOF\Store::set('sub_title', _t('Confirm user'));
        $this->smarty->assign('result', $action['result']);
    }

    public function forgot() {

        $this->view = 'user/forgot';
        \CODOF\Store::set('sub_title', _t('Request new passsword'));
    }

    public static function access_denied() {

        $this->view = 'access_denied';
        \CODOF\Store::set('sub_title', _t('Access Denied'));
    }

    public static function not_found() {

        $this->view = 'not_found';
        \CODOF\Store::set('sub_title', _t('Not found'));
    }

}
