<?php

namespace JBBCode;
use Exception;

class ParserException extends Exception{
}