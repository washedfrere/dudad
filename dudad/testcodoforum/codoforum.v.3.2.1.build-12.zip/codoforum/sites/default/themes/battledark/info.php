<?php

$info['name'] = 'battledark';
$info['description'] = 'A dark gaming theme';
$info['version'] = '1.x';
$info['parent_theme']='default';
$info['author'] = "Codologic";
$info['author_url'] = 'http://codologic.com';
$info['license'] = 'Core License';
$info['core'] = '1.x';
