<?php

$info['name'] = 'Mail Notify';
$info['description'] = 'Emails about new topics and posts based on subscription';
$info['version'] = '2.x';
$info['author'] = "Adesh D'Silva";
$info['author_url'] = 'http://codologic.com';
$info['license'] = 'GNU GPL V3';
$info['core'] = '2.x';

