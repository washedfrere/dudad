codolike
========

Like function for CodoForum

1. Download and unpack in "sites/default/plugins"
2. Login you admin and click "Plugins" in your left menu
3. Click the "install" button near "CodoLike"
4. Enjoy it ;)
