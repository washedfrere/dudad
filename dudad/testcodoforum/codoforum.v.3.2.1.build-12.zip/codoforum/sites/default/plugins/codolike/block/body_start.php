<?php
/**
 * CodoLike
 * @copyright  Copyright (c) 2015 Riccardo Tempesta (http://www.riccardotempesta.com)
 */
?>
<script type="text/javascript">
codo_defs.trans.notify.new_like=<?php codolike::j('New like') ?>;
codo_defs.trans.notify.new_like_action=<?php codolike::j('clicked like in') ?>;
</script>