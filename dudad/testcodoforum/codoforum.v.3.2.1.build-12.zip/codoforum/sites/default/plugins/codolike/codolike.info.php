<?php
/**
 * CodoLike
 * @copyright  Copyright (c) 2015 Riccardo Tempesta (http://www.riccardotempesta.com)
 */

$info['name'] = 'codoLike';
$info['description'] = 'Like plugin for codoforum';
$info['version'] = '2.x';
$info['author'] = "Riccardo Tempesta";
$info['author_url'] = 'http://www.riccardotempesta.com';
$info['license'] = 'GNU GPL V3';
$info['core'] = '2.x';